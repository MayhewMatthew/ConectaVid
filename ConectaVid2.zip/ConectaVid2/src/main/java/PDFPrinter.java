//@author: Mayhew Matthew

//Imports:
import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class PDFPrinter {
    public void printpdf(){
    try {
            
            String file_name = JOptionPane.showInputDialog("Digite o nome do arquivo: ");
            String file_place = "C:\\";
            String file_name_and_place = "C:\\File\\" + file_name + ".pdf";
            Document document = new Document();           
            PdfWriter.getInstance(document,new FileOutputStream(file_name_and_place));
            document.open();
            ConnectionFactory myConn = new ConnectionFactory();
            Connection connection = myConn.getConnection();
            PreparedStatement ps = null;
            ResultSet rs = null;
            String query = "SELECT * FROM tb_pacientes";
            ps = connection.prepareStatement(query);
            rs=ps.executeQuery();
            
            while(rs.next()){
                PdfPTable table = new PdfPTable(3);
        
                Paragraph para = new Paragraph(rs.getString("UID")+" "+rs.getString("Nome")+" "+rs.getString("Endereço")+" "+rs.getString("Idade")+" "+rs.getString("Medicina")+" "+rs.getString("DataVacinação"));
                document.add(para);
                document.add(new Paragraph(" "));
                
            }
            document.close();
            JOptionPane.showMessageDialog(null, "Seu arquivo foi criado com sucesso em "+file_name_and_place);
        }         
        catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Ocorreu um erro, tente novamente, por favor.");
            e.printStackTrace();
        }
}
}
