package mayhew_matthew.conectavid2;

//@Author: MayhewMatthew
public class LoginSession {
    public static int UID;
    public static String Usertype;
    public static String Nickname;
    public static boolean isLoggedIn = false;
    
}
