//@Author: MayhewMatthew
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Operations {
     
public static boolean isLogin(String username, String password, String usertype, JFrame frame){
        try{
            Connection myConn = ConnectionFactory.getConnection();
            String sQLQuery = "SELECT UID, Usertype, Nickname FROM login WHERE Username = '"+
            username+
            "' AND password = '"+
            password+
            "' AND Usertype = '"+
            usertype+
            "'";
            PreparedStatement preparedStatement = myConn.prepareStatement(sQLQuery);
            ResultSet resultSet = preparedStatement.executeQuery();
                while (resultSet.next()){
                    LoginSession.UID = resultSet.getInt("UID");
                    LoginSession.Usertype = resultSet.getString("Usertype");
                    LoginSession.Nickname = resultSet.getString("Nickname");
                    
                    return true;
                }    
        }
        catch (Exception exception){
            JOptionPane.showMessageDialog(frame, "Erro na base de dados: " + exception.getMessage());
            
        }
        return false;
}
 
}

 /*Solução que o Bossini sugeriu:
String sql  = "SELECT * FROM tb_login WHERE Username = ? AND pass = ? AND Usertype = ?";
  
  ConnectionFactory factory = new ConnectionFactory();
 
  try(Connection c = factory.getConnection()){
  PreparedStatement ps = c.prepareStatement(sql);
  ps.setString(1, username);
  ps.setString(2, pass);
  ps.setString(3, usertype);
}       catch (Exception e) {
            e.printStackTrace();
        }*/