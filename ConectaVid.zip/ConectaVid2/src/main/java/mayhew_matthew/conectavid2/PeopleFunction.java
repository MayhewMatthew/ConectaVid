package mayhew_matthew.conectavid2;


import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

//@Author: Mayhew Matthew

public class PeopleFunction{
    private String username;
    private String age;
    private String address;
    private String profission;
    
    public void insert(String username, String age, String address, String profission){
        this.username = username;
        this.age = age;
        this.address = address;
        this.profission = profission;
        String SQL = "INSERT INTO tb_pacientes (Nome, Idade, Endereço, Medicina) VALUES (?, ?, ?, ?)";
        ConnectionFactory factory = new ConnectionFactory();
        try(Connection c = factory.getConnection()) {
            PreparedStatement ps = c.prepareStatement(SQL);
            ps.setString(1, username);
            ps.setString(2, age);
            ps.setString(3, address);
            ps.setString(4, profission);
            ps.execute();
        }catch(Exception e){
            JOptionPane.showMessageDialog(null, "Ocorreu um erro na colocação do paciente. Por favor, tente novamente.");
        }
    }
}
