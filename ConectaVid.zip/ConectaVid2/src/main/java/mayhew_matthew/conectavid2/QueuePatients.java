package mayhew_matthew.conectavid2;

//@Author: MayhewMatthew
import java.util.LinkedList;
import java.util.Queue;
import javax.swing.JOptionPane;
public class QueuePatients {
    public void queue(){
    Queue<String> patientLine = new LinkedList<String>();
    patientLine.add("Mayhew");
    patientLine.add("Charles");
    patientLine.add("Augustus");
    JOptionPane.showMessageDialog(null, patientLine);
}
    
    
}
