//@Author: MayhewMatthew
import javax.swing.JFrame;


public class LogOut {
    public static void logOut(JFrame context, PreLogin loginScreen){
    LoginSession.isLoggedIn = false;
    context.setVisible(false);
    loginScreen.setVisible(true);
    
}
}
