package mayhew_matthew.conectavid2;

//@Author: MayhewMatthew
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class WorkersFunction {
    private String username;
    private String password;
    private String usertype;
    private String nickname;
    private String UID;
public void insert (String username, String password, String usertype, String nickname){
    this.username = username;
    this.password = password;
    this.usertype = usertype;
    this.nickname = nickname;
    String SQL = "INSERT INTO login (Username, Password, Usertype, Nickname) VALUES (?, ?, ?, ?)";
    ConnectionFactory factory = new ConnectionFactory();
    try(Connection c = factory.getConnection()){
        PreparedStatement ps = c.prepareStatement(SQL);
        ps.setString(1, username);
        ps.setString(2, password);
        ps.setString(3, usertype);
        ps.setString(4, nickname);
        ps.execute();
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null,"Ocorreu um erro ao cadastrar o usuário. Tente novamente");
        e.printStackTrace();
    }
}
public void delete(String username){
    this.username = username;
    
    String SQL ="DELETE FROM login WHERE Username = ?";
    ConnectionFactory factory = new ConnectionFactory();
    try(Connection c = factory.getConnection()){
        PreparedStatement ps = c.prepareStatement(SQL);
        ps.setString(1, username);
        ps.execute();
    }
    catch(Exception e){
        JOptionPane.showMessageDialog(null, "Ocorreu um erro ao deletar o usuário. Por favor, tente novamente.");
        e.printStackTrace();
    }
}
}

