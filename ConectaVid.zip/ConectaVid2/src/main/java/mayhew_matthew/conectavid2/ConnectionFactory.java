package mayhew_matthew.conectavid2;

//@Author: MayhewMatthew
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionFactory {
    public static Connection getConnection() throws Exception{
        String dbURL = "jdbc:mysql://127.0.0.1:3306/db_login?useTimezone=true&serverTimezone=America/Sao_Paulo";
        String hostUserName = "root";
        String hostPassword = "28A12b67";
        
       
        Class.forName("com.mysql.jdbc.Driver");
       
        Connection myConn = (Connection)DriverManager.getConnection(dbURL,hostUserName,hostPassword);
        return myConn;
                
    }
    
}
